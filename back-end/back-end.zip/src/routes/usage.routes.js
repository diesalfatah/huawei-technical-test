// SECTION IMPORTS
const express = require('express');
const router = express.Router();
const { createUsage, getUsage } = require('../controllers/usage.controller');

// SECTION ROUTES
router.post('/usage', createUsage);
router.get('/usage', getUsage); // ?subscriberId=SUB01 optional

module.exports = router;