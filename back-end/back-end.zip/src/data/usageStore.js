// SECTION IN-MEMORY DATA STORE
let usageRecords = [];
let idCounter = 1;

// SECTION CRUD FUNCTIONS
function addUsage({ subscriberId, callMinutes, smsCount, dataUsageMB }) {
  const record = {
    id: idCounter++,
    subscriberId,
    callMinutes,
    smsCount,
    dataUsageMB,
    timestamp: new Date().toISOString(),
  };
  usageRecords.push(record);
  return record;
}

function getAllUsage() {
  return usageRecords;
}

function getUsageBySubscriber(subscriberId) {
  return usageRecords.filter((r) => r.subscriberId === subscriberId);
}

module.exports = { addUsage, getAllUsage, getUsageBySubscriber };