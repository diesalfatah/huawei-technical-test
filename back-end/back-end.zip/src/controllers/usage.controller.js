// SECTION IMPORTS
const usageStore = require('../data/usageStore');

// SECTION CONTROLLERS
function createUsage(req, res) {
  const { subscriberId, callMinutes, smsCount, dataUsageMB } = req.body;

  // SECTION VALIDATION
  if (
    !subscriberId ||
    callMinutes == null ||
    smsCount == null ||
    dataUsageMB == null
  ) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const record = usageStore.addUsage({
    subscriberId,
    callMinutes,
    smsCount,
    dataUsageMB,
  });

  return res.status(201).json(record);
}

function getUsage(req, res) {
  const { subscriberId } = req.query;

  const records = subscriberId
    ? usageStore.getUsageBySubscriber(subscriberId)
    : usageStore.getAllUsage();

  return res.status(200).json(records);
}

module.exports = { createUsage, getUsage };